
var aa = document.getElementById("1"); 
var bb = document.getElementById("2"); 
var cc = document.getElementById("3"); 
var dd = document.getElementById("4"); 
var ee = document.getElementById("5"); 
var ff = document.getElementById("6"); 
var gg = document.getElementById("7"); 
var hh = document.getElementById("8"); 
var ii = document.getElementById("9"); 
var jj = document.getElementById("10"); 
var kk = document.getElementById("11"); 
var ll = document.getElementById("12"); 
var mm = document.getElementById("13"); 
var nn = document.getElementById("14"); 
var oo = document.getElementById("15"); 
var pp = document.getElementById("16"); 
var qq = document.getElementById("17"); 
function a() { 
    aa.play(); 
} 
function b() { 
    bb.play(); 
} 
function c() { 
    cc.play(); 
} 
function d() { 
    dd.play(); 
} 
function e() { 
    ee.play(); 
} 
function f() { 
    ff.play(); 
} 
function g() { 
    gg.play(); 
} 
function h() { 
    hh.play(); 
} 
function i() { 
    ii.play(); 
} 
function j() { 
    jj.play(); 
} 
function k() { 
    kk.play(); 
} 
function l() { 
    ll.play(); 
} 
function m() { 
    mm.play(); 
} 
function n() { 
    nn.play(); 
} 
function o() { 
    oo.play(); 
} 
function p() { 
    pp.play(); 
} 
function q() { 
    qq.play(); 
} 
